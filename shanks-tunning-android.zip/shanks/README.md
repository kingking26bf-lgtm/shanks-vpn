# Shanks VPN : projet Android complet

## Option A : Android Studio (ordinateur)
1. Installe Android Studio, puis File > Open et choisis ce dossier.
2. Attends la fin de la synchronisation.
3. Build > Build APK(s). L'APK est dans app/build/outputs/apk/debug/app-debug.apk.
4. Envoie-le sur ton téléphone et installe-le (autorise « sources inconnues »).

## Option B : GitHub (gratuit, sans Android Studio)
1. Crée un compte sur github.com et un dépôt vide.
2. Envoie tout le contenu de ce dossier (y compris .github) dans le dépôt.
3. Onglet Actions > « Construire l'APK » > Run workflow.
4. Quand c'est vert, ouvre l'exécution et télécharge l'artefact shanks-vpn-apk.

Note : la conversion lien -> config Xray est faite (XrayConfig.kt). Le cœur Xray natif et tun2socks restent à brancher (TunnelEngine.kt).
