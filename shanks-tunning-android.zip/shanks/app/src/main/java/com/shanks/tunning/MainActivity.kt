package com.shanks.tunning

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.material3.AlertDialog
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState

private val Bg = Color(0xFF140B07); private val CardC = Color(0xFF241610); private val Line = Color(0xFF4A2C1A)
private val Gold = Color(0xFFF5B301); private val Leaf = Color(0xFF3FAE49); private val Muted = Color(0xFFD2B48C)
private val Ring = Color(0xFF8A5A14); private val Mono = FontFamily.Monospace
private val Clay = Color(0xFFD1432A)

fun fmtB(b: Long) = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
    b >= 1L shl 10 -> "%.1f KB".format(b / 1024.0)
    else -> "$b B"
}
fun speed(b: Long) = if (b >= 1L shl 20) "%.1f MB/s".format(b / 1048576.0) else "%.1f KB/s".format(b / 1024.0)
fun dur(ms: Long): String { val m = ms / 60000; val h = m / 60; val d = h / 24
    return if (d > 0) "${d} j ${h % 24} h" else if (h > 0) "${h} h ${m % 60} min" else "${maxOf(m, 1)} min" }
private fun Modifier.card() = this.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(CardC)
    .border(1.dp, Line, RoundedCornerShape(26.dp)).padding(16.dp)
private fun toast(c: Context, t: String) = Toast.makeText(c, t, Toast.LENGTH_SHORT).show()

private fun connect(ctx: Context) {
    val p = currentProfile(ctx)
    if (p == null) return toast(ctx, "Importe d’abord un serveur")
    if (p.expired) return toast(ctx, "Ce serveur a expiré")
    ContextCompat.startForegroundService(ctx, Intent(ctx, ShanksVpnService::class.java)
        .setAction(ShanksVpnService.START).putExtra("config", p.link))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { ShanksApp() } }
}

@Composable
fun ShanksApp() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var screen by remember { mutableStateOf("home") }
    var profiles by remember { mutableStateOf(Store.load(ctx)) }
    var selId by remember { mutableStateOf(Store.selectedId(ctx)) }
    val sel = profiles.firstOrNull { it.id == selId } ?: profiles.firstOrNull()
    val ui by ShanksVpnService.state.collectAsState()
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) connect(ctx)
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        ShanksVpnService.state.update { it.copy(ip = fetchIp()) }
    }
    val go: (String) -> Unit = { screen = it; scope.launch { drawer.close() } }
    ModalNavigationDrawer(drawerState = drawer, drawerContent = { DrawerContent(screen, go, ctx) }) {
        Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
            Header { scope.launch { drawer.open() } }
            Kente(Modifier.fillMaxWidth().height(10.dp))
            Box(Modifier.weight(1f)) {
                when (screen) {
                    "home" -> Home(ui, sel, { go("servers") }) {
                        if (ui.status != Status.DISCONNECTED)
                            ctx.startService(Intent(ctx, ShanksVpnService::class.java).setAction(ShanksVpnService.STOP))
                        else VpnService.prepare(ctx)?.let { perm.launch(it) } ?: connect(ctx)
                    }
                    "import" -> ImportScreen { profiles = Store.load(ctx); go("servers") }
                    "servers" -> Servers(profiles, sel?.id, onSelect = { Store.select(ctx, it); selId = it; go("home") },
                        onDelete = { id -> Store.save(ctx, profiles.filter { it.id != id }); profiles = Store.load(ctx) },
                        onAdd = { go("import") })
                    "usage" -> UsageScreen(ui)
                    "setting" -> SettingsScreen()
                    "hwid" -> HwId()
                    "myip" -> MyIp(ui)
                    "ports", "http" -> NetTool(screen)
                    "guide" -> Guide()
                    else -> About()
                }
            }
            NavBar(screen, go)
        }
    }
}

@Composable
fun Kente(m: Modifier) = Canvas(m) {
    val cols = listOf(Clay, Gold, Leaf, Color(0xFF0B0604), Gold, Clay)
    val u = size.height * 1.6f; var x = 0f; var i = 0
    while (x < size.width) {
        drawRect(cols[i % cols.size], Offset(x, 0f), Size(u, size.height))
        val p = Path().apply { moveTo(x, size.height); lineTo(x + u / 2, size.height * .15f); lineTo(x + u, size.height); close() }
        drawPath(p, cols[(i + 2) % cols.size])
        x += u; i++
    }
}

@Composable
fun Header(onMenu: () -> Unit) = Row(Modifier.fillMaxWidth().padding(18.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Clay, Gold))),
        contentAlignment = Alignment.Center) { Text("⚡", fontSize = 26.sp) }
    Spacer(Modifier.width(14.dp))
    Column(Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("SHANKS VPN", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
            Spacer(Modifier.width(8.dp))
            Text("PRO", color = Leaf, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.border(1.dp, Leaf, RoundedCornerShape(8.dp)).padding(8.dp, 3.dp))
        }
        Text("VpnService Android Core", color = Muted, fontSize = 16.sp)
    }
    Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(CardC).border(1.dp, Line, RoundedCornerShape(14.dp))
        .clickable { onMenu() }, contentAlignment = Alignment.Center) { Text("☰", color = Gold, fontSize = 22.sp) }
}

@Composable
fun DItem(ic: String, lb: String, on: Boolean, click: () -> Unit) = Row(
    Modifier.padding(horizontal = 12.dp, vertical = 2.dp).fillMaxWidth().clip(RoundedCornerShape(30.dp))
        .then(if (on) Modifier.background(Clay.copy(alpha = .35f)) else Modifier).clickable { click() }.padding(16.dp, 13.dp),
    verticalAlignment = Alignment.CenterVertically) {
    Text(ic, fontSize = 20.sp); Spacer(Modifier.width(14.dp)); Text(lb, color = if (on) Gold else Color.White, fontSize = 17.sp)
}

@Composable
fun DrawerContent(cur: String, go: (String) -> Unit, ctx: Context) {
    val nav = listOf(Triple("🏠", "Accueil", "home"), Triple("☰", "Profils", "servers"), Triple("⚙", "Réglages", "setting"), Triple("📖", "Guide", "guide"))
    val add = listOf(Triple("✏", "V2ray", "import"), Triple("⌨", "SSH", "import"), Triple("⚡", "Hysteria2", "import"), Triple("⚡", "TUIC", "import"),
        Triple("🔑", "UDP Custom", null), Triple("🔑", "Psiphon", null), Triple("🔑", "OpenVPN", null))
    val tools = listOf(Triple("🌍", "Recherche IP", null), Triple("📊", "Consommation de données", "usage"), Triple("📶", "Ping automatique", null),
        Triple("🔒", "ID matériel", "hwid"), Triple("🌐", "Vérificateur de réponse", "http"), Triple("🚀", "Test de vitesse", null),
        Triple("🌍", "Mon IP", "myip"), Triple("🔌", "Testeur de ports", "ports"), Triple("📤", "Partager l’app", null), Triple("ℹ", "À propos", "about"))
    ModalDrawerSheet(drawerContainerColor = Bg) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Kente(Modifier.fillMaxWidth().height(16.dp))
            Text("SHANKS VPN", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, letterSpacing = 2.sp, modifier = Modifier.padding(22.dp, 18.dp))
            listOf("Navigation" to nav, "Ajouter manuellement" to add, "Outils" to tools).forEach { (t, l) ->
                Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                Text(t, color = Muted, fontSize = 15.sp, modifier = Modifier.padding(24.dp, 14.dp, 24.dp, 6.dp))
                l.forEach { (ic, lb, r) -> DItem(ic, lb, r != null && r == cur) { if (r == null) toast(ctx, "Bientôt disponible") else go(r) } }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
fun NavBar(cur: String, onTab: (String) -> Unit) = Row(Modifier.fillMaxWidth().background(Color(0xFF0F0805)).padding(8.dp)) {
    listOf(Triple("⚡", "Accueil", "home"), Triple("⬇", "Importer", "import"), Triple("☰", "Serveurs", "servers"), Triple("📊", "Conso", "usage")).forEach { (ic, lb, r) ->
        val on = r == cur; val sh = RoundedCornerShape(18.dp)
        Column(Modifier.weight(1f).clip(sh)
            .then(if (on) Modifier.background(Color(0xFF3A2210)).border(1.dp, Ring, sh) else Modifier)
            .clickable { onTab(r) }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(ic, color = if (on) Gold else Muted, fontSize = 22.sp)
            Text(lb, color = if (on) Gold else Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun Home(ui: VpnUi, sel: Profile?, onChange: () -> Unit, onToggle: () -> Unit) {
    val on = ui.status == Status.CONNECTED; val busy = ui.status == Status.CONNECTING
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var wall by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(ui.status) { while (ui.status == Status.CONNECTED) { now = SystemClock.elapsedRealtime(); delay(1000) } }
    LaunchedEffect(Unit) { while (true) { wall = System.currentTimeMillis(); delay(30000) } }
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.3f, 1f,
        infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "p")
    val sec = if (on) (now - ui.connectedAt) / 1000 else 0
    val exp = sel?.expiresAt ?: 0L; val left = exp - wall
    val pill = RoundedCornerShape(50)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp, 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.card(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF3A2210))
                .border(1.dp, Ring, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                Text((sel?.proto ?: "—").take(3).replaceFirstChar { it.uppercase() }, color = Gold, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(sel?.name ?: "Aucun serveur", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (sel?.locked == true) "🔒 Serveur verrouillé" else sel?.host ?: "Importe un serveur", color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("Changer →", color = Gold, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onChange() })
        }
        Column(Modifier.card(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (exp == 0L) "Validité : Illimité (Non définie)" else if (left <= 0) "Validité : Expiré" else "Validité : ${dur(left)} restant",
                color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
            if (exp > 0) {
                val pc = (left.toFloat() / maxOf(exp - (sel?.startAt ?: 0L), 1L).toFloat()).coerceIn(0.02f, 1f)
                Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(Line)) {
                    Box(Modifier.fillMaxWidth(pc).fillMaxHeight().background(if (pc < 0.2f) Color(0xFFFF4D6D) else Gold))
                }
            }
            Text("*L’expiration locale dans l’application ne remplace pas une expiration imposée par le serveur distant.", color = Muted, fontSize = 13.sp)
        }
        Box(Modifier.size(230.dp).clip(CircleShape).background(Color(0xFF1C110B))
            .border(8.dp, if (busy) Gold.copy(alpha = pulse) else if (on) Gold else Ring, CircleShape)
            .clickable { onToggle() }, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val c = Gold
                Canvas(Modifier.size(64.dp)) {
                    val s = Stroke(6.dp.toPx(), cap = StrokeCap.Round); val w = size.width
                    drawArc(c, -60f, 300f, false, Offset(w * .1f, w * .2f), Size(w * .8f, w * .8f), style = s)
                    drawLine(c, Offset(w / 2, 0f), Offset(w / 2, w * .45f), 6.dp.toPx(), StrokeCap.Round)
                }
                Spacer(Modifier.height(8.dp))
                Text(if (on || busy) "DÉCONNECTER" else "CONNECTER", color = Gold, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            }
        }
        Row(Modifier.clip(pill).background(CardC).border(1.dp, Line, pill).padding(22.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (on) Leaf else if (busy) Gold else Muted))
            Spacer(Modifier.width(10.dp))
            Text(if (on) "CONNECTÉ" else if (busy) "CONNEXION…" else "DÉCONNECTÉ", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        }
        ui.error?.let { Text(it, color = Color(0xFFFF6B81), fontSize = 14.sp) }
        Column(Modifier.card()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Metric("↓", "Descente (DL)", speed(ui.rxSpeed), Gold); Metric("↑", "Montée (UL)", speed(ui.txSpeed), Leaf)
            }
            Spacer(Modifier.height(10.dp))
            Chart(ui.history, Modifier.fillMaxWidth().height(140.dp))
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Line)); Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Legend(Gold, "Débit Descendant"); Legend(Leaf, "Débit Ascendant")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("🌐", if (on) "IP du serveur" else "IP publique réelle", ui.ip, if (on) "Via le VPN" else "Hors VPN", Gold, Modifier.weight(1f))
            Tile("⏱", "Durée de connexion", "%02d:%02d:%02d".format(sec / 3600, sec / 60 % 60, sec % 60), "Session courante", Color.White, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("↑", "Données envoyées", fmtB(ui.tx), "Upload mesuré", Leaf, Modifier.weight(1f))
            Tile("↓", "Données reçues", fmtB(ui.rx), "Download mesuré", Gold, Modifier.weight(1f))
        }
        Text(buildAnnotatedString { append("Créé par "); withStyle(SpanStyle(color = Gold, fontWeight = FontWeight.Bold)) { append("FANKANI..SHANKS") } },
            color = Muted, fontSize = 17.sp, modifier = Modifier.padding(vertical = 12.dp))
    }
}

@Composable
fun Metric(icon: String, label: String, value: String, c: Color) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF3A2210)), contentAlignment = Alignment.Center) { Text(icon, color = c, fontSize = 20.sp) }
    Spacer(Modifier.width(10.dp))
    Column { Text(label, color = Muted, fontSize = 15.sp); Text(value, color = c, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
}

@Composable
fun Legend(c: Color, t: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(12.dp).clip(CircleShape).background(c)); Spacer(Modifier.width(8.dp)); Text(t, color = Color.White, fontSize = 15.sp)
}

@Composable
fun Tile(icon: String, title: String, value: String, sub: String, c: Color, m: Modifier) = Column(m.card(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
    Row(verticalAlignment = Alignment.CenterVertically) { Text(icon, color = c, fontSize = 18.sp); Spacer(Modifier.width(8.dp)); Text(title, color = Muted, fontSize = 15.sp) }
    Text(value, color = c, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    Text(sub, color = Muted, fontSize = 14.sp)
}

@Composable
fun Chart(h: List<Pair<Long, Long>>, m: Modifier) = Canvas(m) {
    val max = (h.maxOfOrNull { maxOf(it.first, it.second) } ?: 1L).coerceAtLeast(4096L).toFloat()
    drawLine(Leaf, Offset(0f, size.height), Offset(size.width, size.height), 3.dp.toPx())
    fun line(sel: (Pair<Long, Long>) -> Long, c: Color) {
        if (h.size < 2) return
        val p = Path()
        h.forEachIndexed { i, v ->
            val x = size.width * i / (h.size - 1); val y = size.height * (1 - sel(v) / max)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        drawPath(p, c, style = Stroke(3.dp.toPx()))
    }
    line({ it.first }, Gold); line({ it.second }, Leaf)
}

@Composable
fun Servers(list: List<Profile>, selId: String?, onSelect: (String) -> Unit, onDelete: (String) -> Unit, onAdd: () -> Unit) {
    val df = remember { SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE) }
    var showCfg by remember { mutableStateOf<Profile?>(null) }
    showCfg?.let { p ->
        val cfg = remember(p.id) { runCatching { XrayConfig.fromLink(p.link) }.getOrElse { "Erreur : ${it.message}" } }
        val clip = LocalClipboardManager.current; val ctx = LocalContext.current
        AlertDialog(onDismissRequest = { showCfg = null }, containerColor = CardC,
            confirmButton = { Text("Copier", color = Gold, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { clip.setText(AnnotatedString(cfg)); toast(ctx, "Config copiée") }.padding(12.dp)) },
            dismissButton = { Text("Fermer", color = Muted, modifier = Modifier.clickable { showCfg = null }.padding(12.dp)) },
            title = { Text("Config Xray · ${p.name}", color = Gold, fontSize = 17.sp) },
            text = { Text(cfg, color = Color.White, fontFamily = Mono, fontSize = 11.sp,
                modifier = Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) })
    }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("MES SERVEURS", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 3.sp)
                Text("${list.size}", color = Muted, fontSize = 18.sp)
            }
            if (list.isEmpty()) Text("Aucun serveur. Appuie sur + pour en importer.", color = Muted)
            list.forEach { p ->
                val on = p.id == selId; val sh = RoundedCornerShape(26.dp)
                val bc = when (p.proto) { "trojan" -> Color(0xFFEF4444); "ssh" -> Color(0xFF22C55E); "dnstt" -> Color(0xFFF59E0B); else -> Clay }
                var menu by remember { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth().clip(sh).background(CardC).border(if (on) 2.dp else 1.dp, if (on) Gold else Line, sh)
                    .clickable { onSelect(p.id) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(78.dp).clip(RoundedCornerShape(16.dp)).background(bc).padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                        Text(p.proto.take(5).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (p.locked) {
                            Text("🔒 Serveur verrouillé", color = Muted)
                            if (p.expiresAt > 0) Text("⏳ expire le ${df.format(Date(p.expiresAt))}", color = Gold)
                        } else Text(p.host, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box {
                        Text("⋮", color = Muted, fontSize = 24.sp, modifier = Modifier.clickable { menu = true }.padding(8.dp))
                        DropdownMenu(menu, { menu = false }) { DropdownMenuItem(text = { Text("Voir la config Xray") }, onClick = { menu = false; showCfg = p }); DropdownMenuItem(text = { Text("Supprimer") }, onClick = { menu = false; onDelete(p.id) }) }
                    }
                }
            }
            Spacer(Modifier.height(90.dp))
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(24.dp).size(68.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Clay, Gold))).clickable { onAdd() }, contentAlignment = Alignment.Center) {
            Text("+", color = Color.White, fontSize = 32.sp)
        }
    }
}

@Composable
fun ImportScreen(done: () -> Unit) {
    val ctx = LocalContext.current; val clip = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("IMPORTER", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 3.sp)
        Text("Colle tes liens vmess://, vless://, trojan://, ssh://, dnstt:// (un par ligne).", color = Muted)
        BasicTextField(text, { text = it }, Modifier.fillMaxWidth().heightIn(min = 180.dp).card(),
            textStyle = TextStyle(color = Color.White, fontFamily = Mono, fontSize = 14.sp), cursorBrush = SolidColor(Gold))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Btn("Coller", false, Modifier.weight(1f)) { clip.getText()?.text?.let { text = it } }
            Btn("Importer", true, Modifier.weight(1f)) {
                val lines = text.lines().filter { it.isNotBlank() }
                val found = lines.mapNotNull { parseLink(it) }
                val old = Store.load(ctx); val fresh = found.filter { f -> old.none { it.link == f.link } }
                Store.save(ctx, old + fresh)
                toast(ctx, "${fresh.size} serveur(s) ajouté(s)" + if (lines.size > found.size) ", ${lines.size - found.size} ligne(s) non reconnue(s)" else "")
                if (fresh.isNotEmpty()) done()
            }
        }
    }
}

@Composable
fun Btn(label: String, filled: Boolean, m: Modifier, onClick: () -> Unit) {
    val sh = RoundedCornerShape(18.dp)
    Box(m.clip(sh).then(if (filled) Modifier.background(Brush.linearGradient(listOf(Clay, Gold))) else Modifier.background(CardC).border(1.dp, Line, sh))
        .clickable { onClick() }.padding(vertical = 15.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (filled) Color.White else Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun Page(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
    Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 3.sp); content()
}

@Composable
fun Bars(d: List<Triple<String, Long, Long>>, m: Modifier) = Canvas(m) {
    val max = (d.maxOfOrNull { maxOf(it.second, it.third) } ?: 1L).coerceAtLeast(1024L).toFloat(); val w = size.width / d.size
    drawLine(Line, Offset(0f, size.height), Offset(size.width, size.height), 2.dp.toPx())
    d.forEachIndexed { i, (_, rx, tx) ->
        drawRect(Gold, Offset(i * w + w * .12f, size.height * (1 - rx / max)), Size(w * .34f, size.height * rx / max))
        drawRect(Leaf, Offset(i * w + w * .54f, size.height * (1 - tx / max)), Size(w * .34f, size.height * tx / max))
    }
}

@Composable
fun UsageScreen(ui: VpnUi) {
    val ctx = LocalContext.current; var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(5000); tick++ } }
    val days = remember(tick) { Usage.last(ctx, 7) }; val tot = remember(tick) { Usage.total(ctx) }
    val today = days.last(); val week = days.fold(0L) { a, d -> a + d.second + d.third }
    Page("CONSOMMATION") {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("↓", "Session reçu", fmtB(ui.rx), "Session courante", Gold, Modifier.weight(1f))
            Tile("↑", "Session envoyé", fmtB(ui.tx), "Session courante", Leaf, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("📅", "Aujourd’hui", fmtB(today.second + today.third), "↓ ${fmtB(today.second)} · ↑ ${fmtB(today.third)}", Color.White, Modifier.weight(1f))
            Tile("🗓", "7 jours", fmtB(week), "Dernière semaine", Color.White, Modifier.weight(1f))
        }
        Column(Modifier.card()) {
            Text("7 derniers jours", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Spacer(Modifier.height(10.dp)); Bars(days, Modifier.fillMaxWidth().height(150.dp)); Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) { days.forEach { Text(it.first.takeLast(5).replace("-", "/"), color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f)) } }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Legend(Gold, "Reçu"); Legend(Leaf, "Envoyé") }
        }
        Tile("Σ", "Total depuis l’installation", fmtB(tot.first + tot.second), "↓ ${fmtB(tot.first)} · ↑ ${fmtB(tot.second)}", Gold, Modifier.fillMaxWidth())
        Text("Mesure l’ensemble du trafic qui passe par le tunnel, protocole compris.", color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    Page("RÉGLAGES") {
        Btn("Remettre la consommation à zéro", false, Modifier.fillMaxWidth()) { Usage.reset(ctx); toast(ctx, "Consommation remise à zéro") }
        Text("Choix du fond (noir, bleu, rouge, blanc) : bientôt disponible.", color = Muted)
    }
}

@Composable
fun HwId() {
    val ctx = LocalContext.current; val clip = LocalClipboardManager.current
    val id = remember { (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "—").uppercase() }
    Page("ID MATÉRIEL") {
        Column(Modifier.card()) { Text("ID de cet appareil", color = Muted); Text(id, color = Gold, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 22.sp) }
        Btn("Copier l’ID", true, Modifier.fillMaxWidth()) { clip.setText(AnnotatedString(id)); toast(ctx, "ID copié") }
        Text("Sert à lier un export verrouillé à cet appareil.", color = Muted)
    }
}

@Composable
fun MyIp(ui: VpnUi) {
    val scope = rememberCoroutineScope()
    Page("MON IP") {
        Column(Modifier.card()) {
            Text(if (ui.status == Status.CONNECTED) "IP du serveur VPN" else "IP publique réelle", color = Muted)
            Text(ui.ip, color = Gold, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 26.sp)
        }
        Btn("Actualiser", true, Modifier.fillMaxWidth()) {
            scope.launch { ShanksVpnService.state.update { it.copy(ip = "…") }; val ip = fetchIp(); ShanksVpnService.state.update { it.copy(ip = ip) } }
        }
    }
}

@Composable
fun NetTool(mode: String) {
    val scope = rememberCoroutineScope(); var input by remember(mode) { mutableStateOf(if (mode == "http") "https://" else "") }
    var out by remember(mode) { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    Page(if (mode == "http") "VÉRIFICATEUR DE RÉPONSE" else "TESTEUR DE PORTS") {
        Text(if (mode == "http") "Adresse complète (https://…)" else "Hôte et port, ex. exemple.com:443", color = Muted)
        BasicTextField(input, { input = it }, Modifier.fillMaxWidth().card(), singleLine = true, cursorBrush = SolidColor(Gold),
            textStyle = TextStyle(color = Color.White, fontFamily = Mono, fontSize = 16.sp))
        Btn(if (busy) "Test en cours…" else "Tester", true, Modifier.fillMaxWidth()) {
            if (busy) return@Btn
            busy = true; out = ""
            scope.launch {
                out = withContext(Dispatchers.IO) {
                    val t0 = SystemClock.elapsedRealtime()
                    try {
                        if (mode == "http") {
                            val c = URL(input.trim()).openConnection() as HttpURLConnection
                            c.connectTimeout = 6000; c.readTimeout = 6000
                            "Code ${c.responseCode} ${c.responseMessage.orEmpty()} · ${SystemClock.elapsedRealtime() - t0} ms"
                        } else {
                            val (h, p) = input.trim().split(":").let { it[0] to it[1].toInt() }
                            Socket().use { it.connect(InetSocketAddress(h, p), 5000) }
                            "Port $p ouvert · ${SystemClock.elapsedRealtime() - t0} ms"
                        }
                    } catch (e: Exception) { "Échec : ${e.message ?: "pas de réponse"}" }
                }
                busy = false
            }
        }
        if (out.isNotEmpty()) Column(Modifier.card()) { Text(out, color = Gold, fontFamily = Mono, fontSize = 17.sp) }
    }
}

@Composable
fun Guide() = Page("GUIDE") {
    Column(Modifier.card(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf("1. Onglet Importer : colle tes liens (vmess, vless, trojan, ssh, dnstt).", "2. Onglet Serveurs : touche un serveur pour le choisir.",
            "3. Accueil : touche CONNECTER et accepte la demande VPN.", "4. Onglet Conso : suis ta consommation jour par jour.").forEach { Text(it, color = Color.White, fontSize = 16.sp) }
    }
}

@Composable
fun About() = Page("À PROPOS") {
    Column(Modifier.card(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("SHANKS VPN PRO", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text("Version 1.0 · VpnService Android Core", color = Muted)
        Text(buildAnnotatedString { append("Créé par "); withStyle(SpanStyle(color = Gold, fontWeight = FontWeight.Bold)) { append("FANKANI..SHANKS") } }, color = Muted, fontSize = 17.sp)
    }
}
