package com.shanks.tunning

import android.net.VpnService

/** Moteur du tunnel : c'est ici que se branchent Xray et tun2socks. */
interface TunnelEngine {
    /** Démarre le tunnel. `config` est le lien du serveur choisi. Lance une exception si la connexion échoue. */
    fun start(tunFd: Int, config: String, vpn: VpnService)
    fun stop()
}

class XrayEngine : TunnelEngine {
    override fun start(tunFd: Int, config: String, vpn: VpnService) {
        // 1) Lien -> JSON Xray (erreur claire si SSH, DNSTT, etc.)
        val json = XrayConfig.fromLink(config)
        // 2) À FAIRE : démarrer le cœur Xray avec `json` (bibliothèque native),
        //    puis tun2socks : lit tunFd et envoie vers 127.0.0.1:${XrayConfig.SOCKS_PORT}.
        //    Chaque socket sortant de Xray doit passer par vpn.protect(socket).
        throw NotImplementedError("Config Xray prête (${json.length} caractères), mais le cœur Xray n’est pas encore branché")
    }
    override fun stop() { /* arrêter tun2socks puis Xray */ }
}
