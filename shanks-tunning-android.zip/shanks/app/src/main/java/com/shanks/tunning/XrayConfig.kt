package com.shanks.tunning

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder

/** Convertit un lien (vmess, vless, trojan, ss) en configuration JSON Xray. */
object XrayConfig {
    const val SOCKS_PORT = 10808   // port local vers lequel tun2socks enverra le trafic

    fun fromLink(link: String): String {
        val l = link.trim(); val proto = l.substringBefore("://").lowercase()
        val out = when (proto) {
            "vmess" -> vmess(l); "vless" -> vless(l); "trojan" -> trojan(l); "ss" -> shadowsocks(l)
            else -> throw IllegalArgumentException("${proto.uppercase()} n’est pas pris en charge par Xray")
        }
        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("dns", JSONObject().put("servers", JSONArray(listOf("1.1.1.1", "8.8.8.8"))))
            .put("inbounds", JSONArray().put(JSONObject().put("tag", "socks").put("listen", "127.0.0.1")
                .put("port", SOCKS_PORT).put("protocol", "socks")
                .put("settings", JSONObject().put("auth", "noauth").put("udp", true))
                .put("sniffing", JSONObject().put("enabled", true).put("destOverride", JSONArray(listOf("http", "tls", "quic"))))))
            .put("outbounds", JSONArray().put(out)
                .put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
                .put(JSONObject().put("tag", "block").put("protocol", "blackhole")))
            .toString(2)
    }

    private fun q(u: URI): Map<String, String> = (u.rawQuery ?: "").split("&").filter { it.isNotEmpty() }
        .associate { it.substringBefore("=") to URLDecoder.decode(it.substringAfter("=", ""), "UTF-8") }

    private fun stream(net: String, sec: String, p: Map<String, String>, addr: String): JSONObject {
        val s = JSONObject().put("network", net).put("security", sec)
        val host = p["host"].orEmpty()
        when (net) {
            "ws" -> s.put("wsSettings", JSONObject().put("path", p["path"].orEmpty().ifEmpty { "/" })
                .apply { if (host.isNotEmpty()) put("headers", JSONObject().put("Host", host)) })
            "grpc" -> s.put("grpcSettings", JSONObject().put("serviceName", p["serviceName"].orEmpty()))
            "h2", "http" -> s.put("network", "h2").put("httpSettings", JSONObject()
                .put("path", p["path"].orEmpty().ifEmpty { "/" }).put("host", JSONArray(listOf(host.ifEmpty { addr }))))
        }
        if (sec == "tls") s.put("tlsSettings", JSONObject()
            .put("serverName", p["sni"].orEmpty().ifEmpty { host.ifEmpty { addr } })
            .put("allowInsecure", p["allowInsecure"] == "1" || p["allowInsecure"] == "true")
            .apply {
                p["fp"]?.takeIf { it.isNotEmpty() }?.let { put("fingerprint", it) }
                p["alpn"]?.takeIf { it.isNotEmpty() }?.let { put("alpn", JSONArray(it.split(","))) }
            })
        if (sec == "reality") s.put("realitySettings", JSONObject()
            .put("serverName", p["sni"].orEmpty()).put("fingerprint", p["fp"].orEmpty().ifEmpty { "chrome" })
            .put("publicKey", p["pbk"].orEmpty()).put("shortId", p["sid"].orEmpty()).put("spiderX", p["spx"].orEmpty()))
        return s
    }

    private fun vmess(l: String): JSONObject {
        val j = JSONObject(String(Base64.decode(l.substring(8), Base64.DEFAULT)))
        val add = j.getString("add")
        val p = mapOf("host" to j.optString("host"), "path" to j.optString("path"), "sni" to j.optString("sni"),
            "fp" to j.optString("fp"), "alpn" to j.optString("alpn"), "serviceName" to j.optString("path"))
        return JSONObject().put("tag", "proxy").put("protocol", "vmess")
            .put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                .put("address", add).put("port", j.optString("port").toInt())
                .put("users", JSONArray().put(JSONObject().put("id", j.getString("id"))
                    .put("alterId", j.optString("aid", "0").toIntOrNull() ?: 0)
                    .put("security", j.optString("scy").ifEmpty { "auto" }))))))
            .put("streamSettings", stream(j.optString("net", "tcp"), if (j.optString("tls") == "tls") "tls" else "none", p, add))
    }

    private fun vless(l: String): JSONObject {
        val u = URI(l); val p = q(u)
        return JSONObject().put("tag", "proxy").put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject()
                .put("address", u.host).put("port", u.port)
                .put("users", JSONArray().put(JSONObject().put("id", u.userInfo).put("encryption", p["encryption"] ?: "none")
                    .apply { p["flow"]?.takeIf { it.isNotEmpty() }?.let { put("flow", it) } })))))
            .put("streamSettings", stream(p["type"] ?: "tcp", p["security"] ?: "none", p, u.host))
    }

    private fun trojan(l: String): JSONObject {
        val u = URI(l); val p = q(u)
        return JSONObject().put("tag", "proxy").put("protocol", "trojan")
            .put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                .put("address", u.host).put("port", u.port).put("password", URLDecoder.decode(u.rawUserInfo, "UTF-8")))))
            .put("streamSettings", stream(p["type"] ?: "tcp", p["security"] ?: "tls", p, u.host))
    }

    private fun shadowsocks(l: String): JSONObject {
        val body = l.substring(5).substringBefore("#")
        val parts = if (body.contains("@")) {
            val u = URI("ss://$body"); val ui = u.rawUserInfo
            val dec = runCatching { String(Base64.decode(ui, Base64.URL_SAFE or Base64.NO_PADDING)) }
                .getOrDefault(URLDecoder.decode(ui, "UTF-8"))
            listOf(dec.substringBefore(":"), dec.substringAfter(":"), u.host, u.port.toString())
        } else {
            val dec = String(Base64.decode(body.substringBefore("?"), Base64.URL_SAFE or Base64.NO_PADDING))
            val hp = dec.substringAfterLast("@"); val cred = dec.substringBeforeLast("@")
            listOf(cred.substringBefore(":"), cred.substringAfter(":"), hp.substringBeforeLast(":"), hp.substringAfterLast(":"))
        }
        return JSONObject().put("tag", "proxy").put("protocol", "shadowsocks")
            .put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                .put("address", parts[2]).put("port", parts[3].toInt()).put("method", parts[0]).put("password", parts[1]))))
    }
}
