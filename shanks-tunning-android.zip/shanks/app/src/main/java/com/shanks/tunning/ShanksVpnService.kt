package com.shanks.tunning

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.TrafficStats
import android.net.VpnService
import android.os.*
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.net.HttpURLConnection
import java.net.URL

enum class Status { DISCONNECTED, CONNECTING, CONNECTED }

data class VpnUi(
    val status: Status = Status.DISCONNECTED,
    val rx: Long = 0, val tx: Long = 0,            // totaux depuis la connexion (octets)
    val rxSpeed: Long = 0, val txSpeed: Long = 0,  // octets par seconde
    val history: List<Pair<Long, Long>> = emptyList(),
    val connectedAt: Long = 0,                     // SystemClock.elapsedRealtime()
    val ip: String = "…",
    val error: String? = null,
)

suspend fun fetchIp(): String = withContext(Dispatchers.IO) {
    try {
        val c = URL("https://api.ipify.org").openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 6000
        c.inputStream.bufferedReader().use { it.readText().trim() }
    } catch (e: Exception) { "Indisponible" }
}

class ShanksVpnService : VpnService() {
    companion object {
        val state = MutableStateFlow(VpnUi())
        const val START = "start"; const val STOP = "stop"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var tun: ParcelFileDescriptor? = null
    private val engine: TunnelEngine = XrayEngine()

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == STOP) disconnect() else connect(i?.getStringExtra("config").orEmpty())
        return START_NOT_STICKY
    }

    private fun connect(config: String) {
        if (job?.isActive == true) return
        ServiceCompat.startForeground(this, 1, notification(),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        state.value = VpnUi(status = Status.CONNECTING, ip = state.value.ip)
        job = scope.launch {
            try {
                require(config.isNotBlank()) { "Aucune configuration Xray enregistrée" }
                tun = Builder().setSession("Shanks Tunning").setMtu(1500)
                    .addAddress("10.10.14.1", 30).addRoute("0.0.0.0", 0).addDnsServer("1.1.1.1")
                    .establish() ?: error("Permission VPN refusée")
                engine.start(tun!!.fd, config, this@ShanksVpnService)

                // Stats réelles : octets échangés par ce processus avec le réseau,
                // soit tout le trafic qui sort du tunnel (Xray tourne dans notre UID).
                val uid = Process.myUid()
                val rx0 = TrafficStats.getUidRxBytes(uid); val tx0 = TrafficStats.getUidTxBytes(uid)
                state.update { it.copy(status = Status.CONNECTED, connectedAt = SystemClock.elapsedRealtime()) }
                launch { delay(1500); state.update { it.copy(ip = fetchIp()) } } // IP du serveur
                var lr = rx0; var lt = tx0; var pr = 0L; var pt = 0L; var n = 0
                try { while (isActive) {
                    delay(1000)
                    val r = TrafficStats.getUidRxBytes(uid); val t = TrafficStats.getUidTxBytes(uid)
                    state.update {
                        it.copy(rx = r - rx0, tx = t - tx0, rxSpeed = r - lr, txSpeed = t - lt,
                            history = (it.history + ((r - lr) to (t - lt))).takeLast(60))
                    }
                    pr += r - lr; pt += t - lt; lr = r; lt = t
                    if (++n % 10 == 0) { Usage.add(applicationContext, pr, pt); pr = 0; pt = 0 }
                } } finally { Usage.add(applicationContext, pr, pt) }
            } catch (e: CancellationException) { throw e
            } catch (e: Throwable) {
                cleanup(); state.value = VpnUi(error = e.message ?: "Échec de la connexion")
            }
        }
    }

    private fun disconnect() {
        job?.cancel(); cleanup()
        state.value = VpnUi()
        scope.launch { delay(1000); state.update { it.copy(ip = fetchIp()) } } // IP réelle
    }

    private fun cleanup() {
        runCatching { engine.stop() }
        runCatching { tun?.close() }; tun = null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onRevoke() { disconnect() }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private fun notification(): Notification {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "vpn").setContentTitle("Shanks Tunning")
            .setContentText("VPN actif").setSmallIcon(android.R.drawable.ic_lock_lock).setOngoing(true).build()
    }
}
