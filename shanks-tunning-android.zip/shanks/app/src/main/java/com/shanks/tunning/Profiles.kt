package com.shanks.tunning

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Profile(
    val id: String, val name: String, val proto: String, val host: String, val link: String,
    val locked: Boolean = false, val startAt: Long = 0, val expiresAt: Long = 0,
) { val expired get() = expiresAt > 0 && System.currentTimeMillis() >= expiresAt }

object Store {
    private fun p(c: Context) = c.getSharedPreferences("shanks", Context.MODE_PRIVATE)
    fun load(c: Context): List<Profile> = runCatching {
        val a = JSONArray(p(c).getString("profiles", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Profile(o.getString("id"), o.getString("name"), o.getString("proto"), o.getString("host"),
                o.getString("link"), o.optBoolean("locked"), o.optLong("startAt"), o.optLong("expiresAt"))
        }
    }.getOrDefault(emptyList())
    fun save(c: Context, l: List<Profile>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("proto", it.proto).put("host", it.host)
            .put("link", it.link).put("locked", it.locked).put("startAt", it.startAt).put("expiresAt", it.expiresAt)) }
        p(c).edit().putString("profiles", a.toString()).apply()
    }
    fun selectedId(c: Context): String = p(c).getString("selected", "").orEmpty()
    fun select(c: Context, id: String) = p(c).edit().putString("selected", id).apply()
}

fun currentProfile(c: Context): Profile? {
    val l = Store.load(c); return l.firstOrNull { it.id == Store.selectedId(c) } ?: l.firstOrNull()
}

fun parseLink(line: String): Profile? {
    val l = line.trim(); val proto = l.substringBefore("://", "").lowercase()
    if (proto !in setOf("vmess", "vless", "trojan", "ss", "ssh", "dnstt", "hysteria2", "tuic")) return null
    return runCatching {
        val (name, host) = if (proto == "vmess") {
            val j = JSONObject(String(Base64.decode(l.substring(8), Base64.DEFAULT)))
            j.optString("ps", j.getString("add")) to j.getString("add")
        } else { val u = URI(l); URLDecoder.decode(u.rawFragment ?: u.host, "UTF-8") to u.host }
        Profile(UUID.randomUUID().toString(), name, proto, host, l)
    }.getOrNull()
}

object Usage {
    private fun p(c: Context) = c.getSharedPreferences("shanks", Context.MODE_PRIVATE)
    private fun day(t: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))
    private fun all(c: Context) = runCatching { JSONObject(p(c).getString("usage", "{}")) }.getOrDefault(JSONObject())
    fun add(c: Context, rx: Long, tx: Long) {
        if (rx <= 0 && tx <= 0) return
        val o = all(c); val k = day(System.currentTimeMillis()); val a = o.optJSONArray(k)
        o.put(k, JSONArray().put((a?.optLong(0) ?: 0L) + rx).put((a?.optLong(1) ?: 0L) + tx))
        p(c).edit().putString("usage", o.toString()).apply()
    }
    /** Les n derniers jours, du plus ancien au plus récent : (jour, reçu, envoyé) */
    fun last(c: Context, n: Int): List<Triple<String, Long, Long>> {
        val o = all(c)
        return (n - 1 downTo 0).map { val k = day(System.currentTimeMillis() - it * 86400000L); val a = o.optJSONArray(k)
            Triple(k, a?.optLong(0) ?: 0L, a?.optLong(1) ?: 0L) }
    }
    fun total(c: Context): Pair<Long, Long> {
        val o = all(c); var r = 0L; var t = 0L
        o.keys().forEach { val a = o.optJSONArray(it); r += a?.optLong(0) ?: 0L; t += a?.optLong(1) ?: 0L }
        return r to t
    }
    fun reset(c: Context) = p(c).edit().remove("usage").apply()
}
